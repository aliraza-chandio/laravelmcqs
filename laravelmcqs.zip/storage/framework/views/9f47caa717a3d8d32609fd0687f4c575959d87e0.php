<?php $__env->startSection('page-title'); ?> Add New Question <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="right_col" role="main">
   <div>
      <div class="page-title">
         <div class="title_left">
            <h3>Add New Question</h3>
         </div>
         <div class="title_right">
            <div class="col-md-5 col-sm-5 col-lg-12 form-group text-right top_search">
               <a href="/questions" class="btn btn-primary">Back</a>
            </div>
         </div>
      </div>
      <div class="clearfix"></div>
      <div class="row">
         <div class="col-md-12  ">
            <div class="x_panel">
               <div class="x_content">
                  <br />
                   <form action="<?php echo e(route('questions.update',$question->id)); ?>" method="POST">
                     <?php echo csrf_field(); ?>
                     <?php echo method_field('PUT'); ?>
                     <div class="form-group row ">
                        <label class="control-label col-md-3 col-sm-3 fs18">Question*</label>
                        <div class="col-md-9 col-sm-9 ">
                           <input type="text" class="form-control" placeholder="Question" name="name" value="<?php echo e($question->name); ?>" required>
                        </div>
                     </div>
                     <div class="ln_solid"></div>
                     <div class="form-group">
                        <div class="col-md-9 col-sm-9  offset-md-3">
                           <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelmcqs\resources\views/questions/edit.blade.php ENDPATH**/ ?>