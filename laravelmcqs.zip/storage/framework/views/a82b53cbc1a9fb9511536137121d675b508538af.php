<?php $__env->startSection('page-title'); ?>

Questions

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="right_col" role="main">

   <div class="">

      <div class="page-title">

         <div class="title_left">

            <h3>Questions </h3>

         </div>

      </div>



      <div class="title_right">

         <div class="col-md-4 col-sm-4 col-lg-6 mr-auto form-group text-right top_search">

            <a class="btn btn-success" href="<?php echo e(route('questions.create')); ?>"> Add New Question</a>

         </div>

      </div>


      <div class="clearfix"></div>

      <div class="row" style="display: block;">

         <div class="col-md-12 col-sm-12  ">

            <div class="x_panel">

               <div class="x_content">

                  <?php echo $__env->make('layouts.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <table class="table table-striped">

                     <thead>

                        <tr>

                           <th>#</th>

                           <th>Title</th>


                           <th width="280px">Action</th>

                        </tr>

                     </thead>

                     <tbody>

                     	<?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	                        <tr>

	                           <th scope="row"><?php echo e(++$i); ?></th>

                             <td><?php echo e($question->name); ?></td>


	                           <td>

                                    <form action="<?php echo e(route('questions.destroy',$question->id)); ?>" method="POST">

                                

                                        

                                

                                        <a class="btn btn-primary"   href="<?php echo e(route('questions.edit',$question->id)); ?>" >Edit</a>

                                

                                        <?php echo csrf_field(); ?>

                                        <?php echo method_field('DELETE'); ?>

                                

                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure do you wan\'t to delete the Question?')">Delete</button>

                                    </form>

                                </td>

	                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                     </tbody>

                  </table>
                  <div class="row text-center justify-content-center"><?php echo e($questions->links()); ?></div>

               </div>

            </div>

         </div>

      </div>

   </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelmcqs\resources\views/questions/index.blade.php ENDPATH**/ ?>