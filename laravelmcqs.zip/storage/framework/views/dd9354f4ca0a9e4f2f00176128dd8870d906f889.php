   
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>
                <div class="card-body">
                    <form action="/quiz-check" method="POST">
                        <?php echo csrf_field(); ?>
                            <?php $__currentLoopData = $quizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="qblock">
                                    <?php
                                    $question = \App\Models\Question::where('id',$quiz->question_id)->first();
                                    $answers = \App\Models\Answer::where('question_id',$quiz->question_id)->get();
                                    ?>
                                    <p class="ques"><?php echo e($question->name); ?></p>
                                    <ol>
                                        <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><label><input type="radio" data-val="<?php echo e($answer->correct_answer); ?>" name="<?php echo e($answer->question_id); ?>" value="<?php echo e($answer->id); ?>" class="chkans"><?php echo e($answer->answer); ?></label></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                </div> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                            <?php if(isset($_GET['page'])): ?>
                                <input type="hidden" name="page" value="<?php echo e($_GET['page']); ?>">
                            <?php else: ?>
                                <input type="hidden" name="page" value="1">
                            <?php endif; ?>
                            <?php if($allQuizes == isset($_GET['page'])): ?>
                                <input type="hidden" name="result" value="result">
                                <input type="submit" name="submit" value="Submit">
                            <?php else: ?>
                                <input type="hidden" name="result" value="remain">
                                <input type="submit" name="submit" value="Next">
                            <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelmcqs\resources\views/home.blade.php ENDPATH**/ ?>