<?php
   
namespace App\Http\Controllers;
  
use Illuminate\Http\Request;
use App\Models\Quiz;
use App\Models\Question;
use App\Models\Answer;
use App\Models\Result;
use Auth;
use DB;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
  
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $quizes =  Quiz::where('status','Easy')->paginate(1);
        $allQuizes =  Quiz::where('status','Easy')->count();
        return view('home',compact('quizes','allQuizes'));
    }
  
    public function viewResult()
    {
        $results =  Result::select('is_correct', DB::raw('count(*) as total'))->where('user_id',Auth::user()->id)->groupBy('is_correct')->get();
        return view('result',compact('results'));
    }
  
    public function quizCheck(Request $request)
    {
        $answers = $request->all();
        $count = 1;
        foreach($answers as $key => $data)
        {
            if ($count == 2) {
                $questionUser = $key;
                $answerUser = $data;
                $question = Question::find($questionUser);
                $answer = Answer::find($answerUser);

                $result = Result::create([
                    'question_id' => $questionUser,
                    'answer_id' => $answerUser,
                    'user_id' => Auth::user()->id,
                    'is_correct' => $answer->correct_answer,
                ]);

            }
            if ($key == 'page') {
                $page = $data;
            }
            if ($key == 'result') {
                $isResult = $data;
            }
            $count++;
        }
        $page++;
        if ($isResult == 'remain') {
            return redirect('/home?page='.$page);
        }
        else
        {
            return redirect('/result');
        }
    }
  
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function adminHome()
    {
        return view('adminHome');
    }
    
}