<?php



	return [

		// Website Name

		'siteName' => 'MCQS', 
		'siteURL' => 'http://laravelmcqs.test',
		'img' => '/public/assets/images',
		'vendor' => '/public/assets/vendors',
		'build' => '/public/assets/build',
		'images' => '/public/assets/images',
		'upload' => '/public/assets/upload',
		'version' => '1.2'
	];