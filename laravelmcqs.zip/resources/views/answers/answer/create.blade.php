@extends('layouts.master')
@section('page-title') Add New Answer @endsection
@section('content')
<div class="right_col" role="main">
   <div>
      <div class="page-title">
         <div class="title_left">
            <h3>Add New Answer</h3>
         </div>
         <div class="title_right">
            <div class="col-md-5 col-sm-5 col-lg-12 form-group text-right top_search">
               <a href="/answers" class="btn btn-primary">Back</a>
            </div>
         </div>
      </div>
      <div class="clearfix"></div>
      <div class="row">
         <div class="col-md-12  ">
            <div class="x_panel">
               <div class="x_content">
                  <br />
                  <form class="form-horizontal form-label-left" action="{{ route('answers.store') }}" method="POST">
                     @csrf
                     <div class="form-group row ">
                        <label class="control-label col-md-3 col-sm-3 fs18">Title*</label>
                        <div class="col-md-9 col-sm-9 ">
                           <input type="text" class="form-control" placeholder="Title" name="title" required>
                        </div>
                     </div>
                     <div class="form-group row ">
                        <label class="control-label col-md-3 col-sm-3 fs18">Code*</label>
                        <div class="col-md-9 col-sm-9 ">
                           <input type="text" class="form-control" placeholder="Code" name="code" required>
                        </div>
                     </div>
                     <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 fs18">Classes*</label>
                        <div class="col-md-9 col-sm-9 ">
                           <select class="form-control" name="class_id" required>
                              <option value="">Please Select</option>
                              @foreach($classes as $class)
                                 <option value="{{ $class->id }}">{{ $class->title }}</option>
                              @endforeach
                           </select>
                        </div>
                     </div>
                     <input type="hidden" name="status" value="Active">
                     {{-- <div class="form-group row">
                        <label class="control-label col-md-3 col-sm-3 fs18">Status*</label>
                        <div class="col-md-9 col-sm-9 ">
                           <select class="form-control" name="status" required>
                              <option value="">Please Select</option>
                              <option value="Active">Active</option>
                              <option value="Deactive">Deactive</option>
                           </select>
                        </div>
                     </div> --}}
                     <div class="ln_solid"></div>
                     <div class="form-group">
                        <div class="col-md-9 col-sm-9  offset-md-3">
                           <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

@endsection